package md.ceiti.tmp.Shop.MVC.Dao;

public interface BaseDao<T> {
    void create(T model);

}
