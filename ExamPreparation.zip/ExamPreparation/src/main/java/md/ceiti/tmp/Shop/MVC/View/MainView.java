package md.ceiti.tmp.Shop.MVC.View;

import lombok.Getter;
import lombok.Setter;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;

@Getter
@Setter
public class MainView extends JFrame {
    CardLayout cardLayout;
    JPanel cardPanel;

    JMenuBar mainMenuBar;

    JPanel defaultTablesPanel;
    JMenu viewMenu;
    JMenuItem viewProductMenuItem, viewClientMenuItem;

    JTable defaultTable;
    DefaultTableModel defaultProductModel, defaultClientModel;
    
    
    JMenu createMenu;
    JMenuItem createProductMenuItem;
    JPanel createProductPanel;

    JMenuItem createClientMenuItem;
    JPanel createClientPanel;
    
    JPanel deletePanel;
    JPanel updatePanel;
    
    


    public MainView(){
        setTitle("Shop");

        createGUI();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 300);
        setVisible(true);
    }

    public void createGUI(){
        //GENERAL
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        add(cardPanel);
        mainMenuBar = new JMenuBar();

        //VIEW MENU
        defaultTablesPanel = new JPanel();
        viewMenu = new JMenu("View");

        viewProductMenuItem = new JMenuItem("Products");
        viewClientMenuItem = new JMenuItem("Clients");

        viewMenu.add(viewProductMenuItem);
        viewMenu.add(viewClientMenuItem);

        mainMenuBar.add(viewMenu);

        setJMenuBar(mainMenuBar);

        defaultTable = new JTable();
        defaultProductModel = new DefaultTableModel();
        defaultClientModel = new DefaultTableModel();

        defaultTablesPanel.add(new JScrollPane(defaultTable));

        cardPanel.add(defaultTablesPanel, "View Panel");


        //CREATE MENU
        createMenu = new JMenu("Create");
        mainMenuBar.add(createMenu);

        createProductMenuItem = new JMenuItem("Product");
        createClientMenuItem = new JMenuItem("Client");

        createMenu.add(createProductMenuItem);
        createMenu.add(createClientMenuItem);

        createProductPanel = new JPanel();
        cardPanel.add(createProductPanel, "Create Product Panel");

        createClientPanel = new JPanel();
        cardPanel.add(createClientPanel, "Create Client Panel");

    }

    public void ViewProductMenuItemListener(ActionListener listener){viewProductMenuItem.addActionListener(listener);}
    public void ViewClientMenuItemListener(ActionListener listener){viewClientMenuItem.addActionListener(listener);}

    public void CreateProductMenuItemListener(ActionListener listener){createProductMenuItem.addActionListener(listener);}
    public void CreateClientMenuItemListener(ActionListener listener){createClientMenuItem.addActionListener(listener);}



}
