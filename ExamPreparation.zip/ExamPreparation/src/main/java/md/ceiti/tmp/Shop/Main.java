package md.ceiti.tmp.Shop;

import md.ceiti.tmp.Shop.MVC.Controller.ClientController;
import md.ceiti.tmp.Shop.MVC.Controller.ProductController;
import md.ceiti.tmp.Shop.MVC.Model.ClientModel;
import md.ceiti.tmp.Shop.MVC.Model.ProductModel;
import md.ceiti.tmp.Shop.MVC.View.ClientView;
import md.ceiti.tmp.Shop.MVC.View.MainView;
import md.ceiti.tmp.Shop.MVC.View.ProductView;

public class Main {

    public static void main(String[] args) {
        MainView mainView = new MainView();
        ProductView productView = new ProductView();
        ClientView clientView = new ClientView();

        ProductModel productModel = new ProductModel();
        ClientModel clientModel = new ClientModel();

        ProductController productController = new ProductController(clientModel, productModel, clientView, productView, mainView);
        ClientController clientController = new ClientController(clientModel, productModel, clientView, productView, mainView);
    }
}
