package md.ceiti.tmp.Shop.MVC.Model;

import Util.ConnectionManager;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class ProductModel {

    public void refreshTable(DefaultTableModel tableModel, JTable table, String query) throws SQLException {
        try(Connection conn = ConnectionManager.createConnection()){
            try(ResultSet resultSet = conn.createStatement().executeQuery(query)){

                tableModel.setColumnCount(0);
                tableModel.setRowCount(0);

                ResultSetMetaData metaData = resultSet.getMetaData();

                int columnCount = metaData.getColumnCount();
                for(int i = 2; i <= columnCount; i++){
                    String columnName = metaData.getColumnName(i).toUpperCase();
                    tableModel.addColumn(columnName);
                }

                while(resultSet.next()){
                    Object[] rowData = new Object[columnCount - 1];
                    for(int i = 2; i <= columnCount; i++){
                        rowData[i - 2] = resultSet.getObject(i);
                    }
                    tableModel.addRow(rowData);
                }
            }

            table.setModel(tableModel);
        }
    }

}
