package md.ceiti.tmp.Shop.MVC.View;

public class ClientView {
}
