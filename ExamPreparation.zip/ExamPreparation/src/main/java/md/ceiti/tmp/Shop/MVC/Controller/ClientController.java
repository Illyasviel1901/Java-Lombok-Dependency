package md.ceiti.tmp.Shop.MVC.Controller;

import md.ceiti.tmp.Shop.MVC.Dao.SqlQueries;
import md.ceiti.tmp.Shop.MVC.Model.ClientModel;
import md.ceiti.tmp.Shop.MVC.Model.ProductModel;
import md.ceiti.tmp.Shop.MVC.View.ClientView;
import md.ceiti.tmp.Shop.MVC.View.MainView;
import md.ceiti.tmp.Shop.MVC.View.ProductView;

import java.sql.SQLException;

public class ClientController implements SqlQueries {

    private MainView mainView;
    private ProductView productView;
    private ClientView clientView;

    private ClientModel clientModel;
    private ProductModel productModel;

    public ClientController(ClientModel cModel, ProductModel pModel, ClientView cView, ProductView pView, MainView mView){
        clientModel = cModel;
        productModel = pModel;
        clientView = cView;
        productView = pView;
        mainView = mView;

        ViewClientMenuItemListener();
        CreateClientMenuItemListener();
    }

    public void ViewClientMenuItemListener(){
        mainView.ViewClientMenuItemListener(e -> {
            mainView.getCardLayout().show(mainView.getCardPanel(), "View Panel");

            try {
                clientModel.refreshTable(mainView.getDefaultClientModel(), mainView.getDefaultTable(), SELECT_ALL_FROM_CLIENT);
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        });
    }

    public void CreateClientMenuItemListener(){
        mainView.CreateClientMenuItemListener(e -> {
            mainView.getCardLayout().show(mainView.getCardPanel(), "Create Client Panel");
        });
    }

}
