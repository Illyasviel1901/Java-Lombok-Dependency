package md.ceiti.tmp.Shop.MVC.Dao;

public interface SqlQueries {
    String SELECT_ALL_FROM_PRODUCT = "SELECT * FROM product";
    String SELECT_ALL_FROM_CLIENT = "SELECT * FROM client";
}
