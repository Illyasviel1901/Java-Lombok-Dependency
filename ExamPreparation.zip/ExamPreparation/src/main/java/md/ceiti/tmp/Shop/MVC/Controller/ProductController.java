package md.ceiti.tmp.Shop.MVC.Controller;

import md.ceiti.tmp.Shop.MVC.Dao.SqlQueries;
import md.ceiti.tmp.Shop.MVC.Model.ClientModel;
import md.ceiti.tmp.Shop.MVC.Model.ProductModel;
import md.ceiti.tmp.Shop.MVC.View.ClientView;
import md.ceiti.tmp.Shop.MVC.View.MainView;
import md.ceiti.tmp.Shop.MVC.View.ProductView;

import java.sql.SQLException;

public class ProductController implements SqlQueries {

    private MainView mainView;
    private ProductView productView;
    private ClientView clientView;

    private ClientModel clientModel;
    private ProductModel productModel;

    public ProductController(ClientModel cModel, ProductModel pModel, ClientView cView, ProductView pView, MainView mView){
        clientModel = cModel;
        productModel = pModel;
        clientView = cView;
        productView = pView;
        mainView = mView;

        ViewProductMenuItemListener();
        CreateProductMenuItemListener();
    }

    private void ViewProductMenuItemListener(){
        mainView.ViewProductMenuItemListener(e -> {
            mainView.getCardLayout().show(mainView.getCardPanel(), "View Panel");

            try {
                productModel.refreshTable(mainView.getDefaultProductModel(), mainView.getDefaultTable(), SELECT_ALL_FROM_PRODUCT);
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        });
    }

    private void CreateProductMenuItemListener(){
        mainView.CreateProductMenuItemListener(e -> {
            mainView.getCardLayout().show(mainView.getCardPanel(), "Create Product Panel");
        });
    }
}
