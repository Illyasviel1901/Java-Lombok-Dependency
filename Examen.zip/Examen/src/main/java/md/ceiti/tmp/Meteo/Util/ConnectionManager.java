package md.ceiti.tmp.Meteo.Util;
import javax.sound.midi.Soundbank;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionManager {

    static Properties PROPERTIES = new Properties();
    static String DATABASE_URL;
    static String USERNAME;
    static String PASSWORD;

    private ConnectionManager(){}

    static{
        try {
            PROPERTIES.load(new FileReader("src\\main\\resources\\database.properties"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        DATABASE_URL = PROPERTIES.getProperty("database.url");
        USERNAME = PROPERTIES.getProperty("username");
        PASSWORD = PROPERTIES.getProperty("password");
    }

    public static Connection createConnection(){
        try{
            return DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
        } catch (Exception e){
            System.out.println(e.getMessage());
            throw new RuntimeException();
        }
    }

}
