package md.ceiti.tmp.Meteo.MVC.Controller;

import md.ceiti.tmp.Meteo.MVC.Dao.SqlQueries;
import md.ceiti.tmp.Meteo.MVC.Model.LocationModel;
import md.ceiti.tmp.Meteo.MVC.Model.MeteoDataModel;
import md.ceiti.tmp.Meteo.MVC.View.MainView;

import javax.swing.*;
import java.sql.SQLException;

public class MeteoDataController implements SqlQueries {

    private MainView mainView;
    private MeteoDataModel meteoDataModel;
    private LocationModel locationModel;

    public MeteoDataController(MeteoDataModel mdModel, LocationModel lModel, MainView mView){
        meteoDataModel = mdModel;
        locationModel = lModel;
        mainView = mView;

        ViewMeteoDataMenuItemListener();
        CreateMeteoDataMenuItemListener();
        CreateMeteoDataButtonListener();

        DeleteMeteoDataMenuItemListener();
        DeleteMeteoDataButtonListener();

    }

    private void ViewMeteoDataMenuItemListener(){
        mainView.ViewMeteoDataMenuItemListener(e -> {
            mainView.getCardLayout().show(mainView.getCardPanel(), "View Panel");

            try {
                meteoDataModel.refreshTable(mainView.getDefaultMeteoDataModel(), mainView.getDefaultTable(), SELECT_ALL_FROM_MeteoData);
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        });
    }

    private void CreateMeteoDataMenuItemListener(){
        mainView.CreateMeteoDataMenuItemListener(e -> {
            mainView.getCardLayout().show(mainView.getCardPanel(), "Create MeteoData Panel");


        });
    }

    public void CreateMeteoDataButtonListener(){
        mainView.CreateMeteoDataButtonListener(e -> {
            try {
                if(validation()){
                    meteoDataModel.create(new MeteoDataModel(
                            mainView.getCreateMeteoDataCodeTextField().getText(),
                            mainView.getCreateMeteoDataDateTextField().getText(),
                            Double.parseDouble(mainView.getCreateMeteoDataTemperatureTextField().getText()),
                            Double.parseDouble(mainView.getCreateMeteoDataHumidityTextField().getText()),
                            Integer.parseInt(mainView.getCreateMeteoDataWindTextField().getText()),
                            mainView.getCreateMeteoDataPrecipitationTextField().getText(),
                            Integer.parseInt(mainView.getCreateMeteoDataPressureTextField().getText()),
                            mainView.getCreateMeteoDataForeignCodeTextField().getText()
                    ));

                    JOptionPane.showMessageDialog(mainView, "Înserarea a fost efectuată cu succes!");
                    mainView.getCreateMeteoDataCodeTextField().setText("");
                    mainView.getCreateMeteoDataDateTextField().setText("");
                    mainView.getCreateMeteoDataTemperatureTextField().setText("");
                    mainView.getCreateMeteoDataHumidityTextField().setText("");
                    mainView.getCreateMeteoDataWindTextField().setText("");
                    mainView.getCreateMeteoDataPrecipitationTextField().setText("");
                    mainView.getCreateMeteoDataPressureTextField().setText("");
                    mainView.getCreateMeteoDataForeignCodeTextField().setText("");
                }
                else{
                    JOptionPane.showMessageDialog(mainView, "Completati toate campurile!", "INPUT ERROR", JOptionPane.WARNING_MESSAGE);
                }

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(mainView, ex.getMessage(), "SQL Error", JOptionPane.WARNING_MESSAGE);
            }

            try {
                meteoDataModel.refreshTable(mainView.getDefaultMeteoDataModel(), mainView.getDefaultTable(), SELECT_ALL_FROM_MeteoData);
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        });
    }

    public boolean validation(){
        if(mainView.getCreateMeteoDataCodeTextField().getText().isEmpty() ||
                mainView.getCreateMeteoDataDateTextField().getText().isEmpty() ||
                mainView.getCreateMeteoDataTemperatureTextField().getText().isEmpty() ||
                mainView.getCreateMeteoDataHumidityTextField().getText().isEmpty() ||
                mainView.getCreateMeteoDataWindTextField().getText().isEmpty() ||
                mainView.getCreateMeteoDataPrecipitationTextField().getText().isEmpty() ||
                mainView.getCreateMeteoDataPressureTextField().getText().isEmpty() ||
                mainView.getCreateMeteoDataForeignCodeTextField().getText().isEmpty()) return false;
        else return true;
    }


    private void DeleteMeteoDataMenuItemListener(){
        mainView.DeleteMeteoDataMenuItemListener(e -> {
            mainView.getCardLayout().show(mainView.getCardPanel(), "Delete MeteoData Panel");
        });
    }
    private void DeleteMeteoDataButtonListener(){
        mainView.DeleteMeteoDataButtonListener(e -> {
            try {
                meteoDataModel.delete(mainView.getDeleteMeteoDataTextField().getText());
                JOptionPane.showMessageDialog(mainView, "Ștergerea datelor meteo fost efectuată cu succes!");
                mainView.getDeleteMeteoDataTextField().setText("");

                meteoDataModel.refreshTable(mainView.getDefaultMeteoDataModel(), mainView.getDefaultTable(), SELECT_ALL_FROM_MeteoData);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(mainView, ex.getMessage(), "SQL Error", JOptionPane.WARNING_MESSAGE);
            }
        });
    }
}
