package md.ceiti.tmp.Meteo.MVC.View;

import lombok.Getter;
import lombok.Setter;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;

@Getter
@Setter
public class MainView extends JFrame {
    CardLayout cardLayout;
    JPanel cardPanel;

    JMenuBar mainMenuBar;

    JPanel defaultTablesPanel;
    JMenu viewMenu;
    JMenuItem viewLocationMenuItem, viewMeteoDataMenuItem;

    JTable defaultTable;
    DefaultTableModel defaultLocationModel, defaultMeteoDataModel;

    //CREATE
    JMenu createMenu;
    JMenuItem createLocationMenuItem;
    JPanel createLocationPanel;
    JPanel createLocationInputPanel;
    JPanel createLocationButtonPanel;

    JLabel createLocationCodeLabel;
    JLabel createLocationTitleLabel;
    JLabel createLocationTypeLabel;
    JLabel createLocationRegionLabel;
    JTextField createLocationCodeTextField;
    JTextField createLocationTitleTextField;
    JTextField createLocationTypeTextField;
    JTextField createLocationRegionTextField;
    JButton createLocationButton;


    JMenuItem createMeteoDataMenuItem;
    JPanel createMeteoDataPanel;

    JPanel createMeteoDataInputPanel;
    JPanel createMeteoDataButtonPanel;

    JLabel createMeteoDataCodeLabel;
    JLabel createMeteoDataDateLabel;
    JLabel createMeteoDataTemperatureLabel;
    JLabel createMeteoDataHumidityLabel;
    JLabel createMeteoDataWindLabel;
    JLabel createMeteoDataPrecipitationLabel;
    JLabel createMeteoDataPressureLabel;
    JLabel createMeteoDataForeignCodeLabel;

    JTextField createMeteoDataCodeTextField;
    JTextField createMeteoDataDateTextField;
    JTextField createMeteoDataTemperatureTextField;
    JTextField createMeteoDataHumidityTextField;
    JTextField createMeteoDataWindTextField;
    JTextField createMeteoDataPrecipitationTextField;
    JTextField createMeteoDataPressureTextField;
    JTextField createMeteoDataForeignCodeTextField;

    JButton createMeteoDataButton;


    //DELETE
    JMenu deleteMenu;
    JMenuItem deleteLocationMenuItem;
    JMenuItem deleteMeteoDataMenuItem;

    JPanel deleteLocationPanel;
    JLabel deleteLocationLabel;
    JTextField deleteLocationTextField;
    JButton deleteLocationButton;

    JPanel deleteMeteoDataPanel;
    JLabel deleteMeteoDataLabel;
    JTextField deleteMeteoDataTextField;
    JButton deleteMeteoDataButton;

    JPanel updatePanel;


    public MainView(){
        setTitle("Meteo");

        createGUI();

        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 300);
        setResizable(false);
        setVisible(true);
    }

    public void createGUI(){
        //GENERAL
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        add(cardPanel);
        mainMenuBar = new JMenuBar();

        //VIEW MENU
        defaultTablesPanel = new JPanel(new BorderLayout());
        viewMenu = new JMenu("View");

        viewLocationMenuItem = new JMenuItem("Locations");
        viewMeteoDataMenuItem = new JMenuItem("MeteoData");

        viewMenu.add(viewLocationMenuItem);
        viewMenu.add(viewMeteoDataMenuItem);

        mainMenuBar.add(viewMenu);

        setJMenuBar(mainMenuBar);

        defaultTable = new JTable();
        defaultLocationModel = new DefaultTableModel();
        defaultMeteoDataModel = new DefaultTableModel();

        defaultTablesPanel.add(new JScrollPane(defaultTable), BorderLayout.CENTER);

        cardPanel.add(defaultTablesPanel, "View Panel");


        //CREATE MENU
        createMenu = new JMenu("Create");
        mainMenuBar.add(createMenu);

        createLocationMenuItem = new JMenuItem("Location");
        createMeteoDataMenuItem = new JMenuItem("MeteoData");

        createMenu.add(createLocationMenuItem);
        createMenu.add(createMeteoDataMenuItem);

        //location
        createLocationPanel = new JPanel(new GridLayout(2, 0));
        createLocationInputPanel = new JPanel(new GridLayout(2, 4));
        createLocationPanel.add(createLocationInputPanel);
        createLocationButtonPanel = new JPanel();
        createLocationPanel.add(createLocationButtonPanel);
        cardPanel.add(createLocationPanel, "Create Location Panel");

        createLocationCodeLabel = new JLabel("                       COD");
        createLocationInputPanel.add(createLocationCodeLabel);
        createLocationTitleLabel = new JLabel("                     DENUMIRE");
        createLocationInputPanel.add(createLocationTitleLabel);
        createLocationTypeLabel = new JLabel("                RURAL/URBAN");
        createLocationInputPanel.add(createLocationTypeLabel);
        createLocationRegionLabel = new JLabel("                MUNICIPIU/RAION");
        createLocationInputPanel.add(createLocationRegionLabel);

        createLocationCodeTextField = new JTextField(5);
        createLocationInputPanel.add(createLocationCodeTextField);
        createLocationTitleTextField = new JTextField(5);
        createLocationInputPanel.add(createLocationTitleTextField);
        createLocationTypeTextField = new JTextField(5);
        createLocationInputPanel.add(createLocationTypeTextField);
        createLocationRegionTextField = new JTextField(5);
        createLocationInputPanel.add(createLocationRegionTextField);

        createLocationButton = new JButton("CREATE");
        createLocationButtonPanel.add(createLocationButton);


        //dateMeteo
        createMeteoDataPanel = new JPanel();
        cardPanel.add(createMeteoDataPanel, "Create MeteoData Panel");

        createMeteoDataPanel = new JPanel(new GridLayout(2, 0));
        createMeteoDataInputPanel = new JPanel(new GridLayout(2, 8));
        createMeteoDataPanel.add(createMeteoDataInputPanel);
        createMeteoDataButtonPanel = new JPanel();
        createMeteoDataPanel.add(createMeteoDataButtonPanel);
        cardPanel.add(createMeteoDataPanel, "Create MeteoData Panel");

        createMeteoDataCodeLabel = new JLabel("        COD");
        createMeteoDataInputPanel.add(createMeteoDataCodeLabel);
        createMeteoDataDateLabel = new JLabel("       DATA");
        createMeteoDataInputPanel.add(createMeteoDataDateLabel);
        createMeteoDataTemperatureLabel = new JLabel(" TEMPERATURA");
        createMeteoDataInputPanel.add(createMeteoDataTemperatureLabel);
        createMeteoDataHumidityLabel = new JLabel("     UMIDITATE");
        createMeteoDataInputPanel.add(createMeteoDataHumidityLabel);
        createMeteoDataWindLabel = new JLabel("         VANT");
        createMeteoDataInputPanel.add(createMeteoDataWindLabel);
        createMeteoDataPrecipitationLabel = new JLabel("    PRECIPITATII");
        createMeteoDataInputPanel.add(createMeteoDataPrecipitationLabel);
        createMeteoDataPressureLabel = new JLabel( "      PRESIUNE");
        createMeteoDataInputPanel.add(createMeteoDataPressureLabel);
        createMeteoDataForeignCodeLabel = new JLabel("       LOCATIE");
        createMeteoDataInputPanel.add(createMeteoDataForeignCodeLabel);

        createMeteoDataCodeTextField = new JTextField(10);
        createMeteoDataInputPanel.add(createMeteoDataCodeTextField);
        createMeteoDataDateTextField = new JTextField(10);
        createMeteoDataInputPanel.add(createMeteoDataDateTextField);
        createMeteoDataTemperatureTextField = new JTextField(10);
        createMeteoDataInputPanel.add(createMeteoDataTemperatureTextField);
        createMeteoDataHumidityTextField = new JTextField(10);
        createMeteoDataInputPanel.add(createMeteoDataHumidityTextField);
        createMeteoDataWindTextField = new JTextField(10);
        createMeteoDataInputPanel.add(createMeteoDataWindTextField);
        createMeteoDataPrecipitationTextField = new JTextField(10);
        createMeteoDataInputPanel.add(createMeteoDataPrecipitationTextField);
        createMeteoDataPressureTextField = new JTextField(10);
        createMeteoDataInputPanel.add(createMeteoDataPressureTextField);
        createMeteoDataForeignCodeTextField = new JTextField(10);
        createMeteoDataInputPanel.add(createMeteoDataForeignCodeTextField);

        createMeteoDataButton = new JButton("CREATE");
        createMeteoDataButtonPanel.add(createMeteoDataButton);



        //DELETE MENU
        deleteMenu = new JMenu("Delete");
        mainMenuBar.add(deleteMenu);

        //locatii
        deleteLocationMenuItem = new JMenuItem("Location");
        deleteMeteoDataMenuItem = new JMenuItem("MeteoData");
        deleteMenu.add(deleteLocationMenuItem);
        deleteMenu.add(deleteMeteoDataMenuItem);

        deleteLocationPanel = new JPanel();
        deleteLocationLabel = new JLabel("Introduceti codul locatiei");
        deleteLocationTextField = new JTextField(5);
        deleteLocationButton = new JButton("DELETE");
        deleteLocationPanel.add(deleteLocationLabel);
        deleteLocationPanel.add(deleteLocationTextField);
        deleteLocationPanel.add(deleteLocationButton);

        cardPanel.add(deleteLocationPanel, "Delete Location Panel");

        //meteodata
        deleteMeteoDataPanel = new JPanel();
        deleteMeteoDataLabel = new JLabel("Introduceti codul datelor meteo");
        deleteMeteoDataTextField = new JTextField(5);
        deleteMeteoDataButton = new JButton("DELETE");
        deleteMeteoDataPanel.add(deleteMeteoDataLabel);
        deleteMeteoDataPanel.add(deleteMeteoDataTextField);
        deleteMeteoDataPanel.add(deleteMeteoDataButton);


        cardPanel.add(deleteMeteoDataPanel, "Delete MeteoData Panel");

    }

    public void ViewLocationMenuItemListener(ActionListener listener){viewLocationMenuItem.addActionListener(listener);}
    public void ViewMeteoDataMenuItemListener(ActionListener listener){viewMeteoDataMenuItem.addActionListener(listener);}

    public void CreateLocationMenuItemListener(ActionListener listener){createLocationMenuItem.addActionListener(listener);}
    public void CreateLocationButtonListener(ActionListener listener){createLocationButton.addActionListener(listener);}
    public void CreateMeteoDataMenuItemListener(ActionListener listener){createMeteoDataMenuItem.addActionListener(listener);}
    public void CreateMeteoDataButtonListener(ActionListener listener){createMeteoDataButton.addActionListener(listener);}

    public void DeleteLocationMenuItemListener(ActionListener listener){deleteLocationMenuItem.addActionListener(listener);}
    public void DeleteLocationButtonListener(ActionListener listener){deleteLocationButton.addActionListener(listener);}
    public void DeleteMeteoDataMenuItemListener(ActionListener listener){deleteMeteoDataMenuItem.addActionListener(listener);}
    public void DeleteMeteoDataButtonListener(ActionListener listener){deleteMeteoDataButton.addActionListener(listener);}




}
