package md.ceiti.tmp.Meteo.MVC.Controller;

import md.ceiti.tmp.Meteo.MVC.Dao.SqlQueries;
import md.ceiti.tmp.Meteo.MVC.Model.MeteoDataModel;
import md.ceiti.tmp.Meteo.MVC.Model.LocationModel;
import md.ceiti.tmp.Meteo.MVC.View.MainView;

import javax.swing.*;
import java.sql.SQLException;

public class LocationController implements SqlQueries {

    private MainView mainView;
    private MeteoDataModel MeteoDataModel;
    private LocationModel locationModel;

    public LocationController(MeteoDataModel mdModel, LocationModel lModel, MainView mView){
        MeteoDataModel = mdModel;
        locationModel = lModel;
        mainView = mView;

        ViewLocationMenuItemListener();
        CreateLocationMenuItemListener();
        CreateLocationButtonListener();
        DeleteLocationMenuItemListener();
        DeleteLocationButtonListener();
    }

    private void ViewLocationMenuItemListener(){
        mainView.ViewLocationMenuItemListener(e -> {
            mainView.getCardLayout().show(mainView.getCardPanel(), "View Panel");

            try {
                locationModel.refreshTable(mainView.getDefaultLocationModel(), mainView.getDefaultTable(), SELECT_ALL_FROM_LOCATION);
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
        });
    }

    private void CreateLocationMenuItemListener(){
        mainView.CreateLocationMenuItemListener(e -> {
            mainView.getCardLayout().show(mainView.getCardPanel(), "Create Location Panel");

        });
    }

    private void CreateLocationButtonListener(){
        mainView.CreateLocationButtonListener(e -> {
            try {
                locationModel.create(new LocationModel(mainView.getCreateLocationCodeTextField().getText(), mainView.getCreateLocationTitleTextField().getText(), mainView.getCreateLocationTypeTextField().getText(), mainView.getCreateLocationRegionTextField().getText()));
                JOptionPane.showMessageDialog(mainView, "Înserarea a fost efectuată cu succes!");
                mainView.getCreateLocationCodeTextField().setText("");
                mainView.getCreateLocationTitleTextField().setText("");
                mainView.getCreateLocationTypeTextField().setText("");
                mainView.getCreateLocationRegionTextField().setText("");

                try {
                    locationModel.refreshTable(mainView.getDefaultLocationModel(), mainView.getDefaultTable(), SELECT_ALL_FROM_LOCATION);
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(mainView, ex.getMessage(), "SQL Error", JOptionPane.WARNING_MESSAGE);
            }
        });
    }

    private void DeleteLocationMenuItemListener(){
        mainView.DeleteLocationMenuItemListener(e -> {
            mainView.getCardLayout().show(mainView.getCardPanel(), "Delete Location Panel");
        });
    }

    private void DeleteLocationButtonListener(){
        mainView.DeleteLocationButtonListener(e -> {
            try {
                locationModel.delete(mainView.getDeleteLocationTextField().getText());
                JOptionPane.showMessageDialog(mainView, "Ștergerea locatiei fost efectuată cu succes!");
                mainView.getDeleteLocationTextField().setText("");

                locationModel.refreshTable(mainView.getDefaultLocationModel(), mainView.getDefaultTable(), SELECT_ALL_FROM_LOCATION);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(mainView, ex.getMessage(), "SQL Error", JOptionPane.WARNING_MESSAGE);
            }
        });
    }
}
