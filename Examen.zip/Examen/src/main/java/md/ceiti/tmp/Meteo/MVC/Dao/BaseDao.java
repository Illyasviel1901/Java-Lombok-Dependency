package md.ceiti.tmp.Meteo.MVC.Dao;

import java.sql.SQLException;

public interface BaseDao<T> {
    String INSERT_INTO_LOCATION = "INSERT INTO Locatii (cod, denumire, tip, municipiu) VALUES (?, ?, ?, ?)";
    String DELETE_LOCATION = "DELETE FROM Locatii WHERE cod = ?";

    String INSERT_INTO_MeteoData = "INSERT INTO DateMeteo (cod, data, temperatura, umiditate, vant, precipitatii, presiune, codLocatie) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    String DELETE_MeteoData = "DELETE FROM DateMeteo WHERE cod = ?";

    void create(T model) throws SQLException;
    void delete(String code) throws SQLException;
}
