package md.ceiti.tmp.Meteo;

import md.ceiti.tmp.Meteo.MVC.View.MainView;
import md.ceiti.tmp.Meteo.MVC.Controller.MeteoDataController;
import md.ceiti.tmp.Meteo.MVC.Controller.LocationController;
import md.ceiti.tmp.Meteo.MVC.Model.MeteoDataModel;
import md.ceiti.tmp.Meteo.MVC.Model.LocationModel;
import md.ceiti.tmp.Meteo.MVC.View.MainView;

public class Main {

    public static void main(String[] args) {
        MainView mainView = new MainView();

        LocationModel locationModel = new LocationModel();
        MeteoDataModel meteoDataModel = new MeteoDataModel();

        LocationController locationController = new LocationController(meteoDataModel, locationModel, mainView);
        MeteoDataController meteoDataController = new MeteoDataController(meteoDataModel, locationModel, mainView);
    }
}
