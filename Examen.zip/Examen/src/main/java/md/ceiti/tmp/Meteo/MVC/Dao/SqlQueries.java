package md.ceiti.tmp.Meteo.MVC.Dao;

public interface SqlQueries {
    String SELECT_ALL_FROM_LOCATION = "SELECT * FROM Locatii";
    String SELECT_ALL_FROM_MeteoData = "SELECT * FROM DateMeteo";
}
