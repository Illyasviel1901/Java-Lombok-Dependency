package md.ceiti.tmp.Meteo.MVC.Model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import md.ceiti.tmp.Meteo.MVC.Dao.BaseDao;
import md.ceiti.tmp.Meteo.Util.ConnectionManager;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class LocationModel implements BaseDao {

    String code;
    String title;
    String type;
    String region;


    public void refreshTable(DefaultTableModel tableModel, JTable table, String query) throws SQLException {
        try(Connection conn = ConnectionManager.createConnection()){
            try(ResultSet resultSet = conn.createStatement().executeQuery(query)){

                tableModel.setColumnCount(0);
                tableModel.setRowCount(0);

                ResultSetMetaData metaData = resultSet.getMetaData();

                int columnCount = metaData.getColumnCount();
                for(int i = 2; i <= columnCount; i++){
                    String columnName = metaData.getColumnName(i).toUpperCase();
                    tableModel.addColumn(columnName);
                }

                while(resultSet.next()){
                    Object[] rowData = new Object[columnCount - 1];
                    for(int i = 2; i <= columnCount; i++){
                        rowData[i - 2] = resultSet.getObject(i);
                    }
                    tableModel.addRow(rowData);
                }
            }

            table.setModel(tableModel);
        }
    }

    @Override
    public void create(Object model) throws SQLException {
        LocationModel locationModel = (LocationModel) model;
        try(Connection conn = ConnectionManager.createConnection()){
            try(PreparedStatement statement = conn.prepareStatement(INSERT_INTO_LOCATION)){
                statement.setString(1, locationModel.getCode());
                statement.setString(2, locationModel.getTitle());
                statement.setString(3, locationModel.getType());
                statement.setString(4, locationModel.getRegion());

                statement.execute();
            }
        }
    }

    @Override
    public void delete(String code) throws SQLException {
        try(Connection conn = ConnectionManager.createConnection()){
            try(PreparedStatement statement = conn.prepareStatement(DELETE_LOCATION)){
                statement.setString(1, code);

                statement.execute();
            }
        }
    }
}
