DROP DATABASE IF EXISTS Meteo;

CREATE DATABASE IF NOT EXISTS Meteo;
use Meteo;

CREATE TABLE Locatii(
	id INT auto_increment PRIMARY KEY,
    cod VARCHAR(255) UNIQUE NOT NULL,
    denumire VARCHAR(255),
    tip VARCHAR(5),
    municipiu VARCHAR(255)
);

CREATE TABLE DateMeteo (
    id INT auto_increment PRIMARY KEY,
    cod VARCHAR(255) UNIQUE NOT NULL,
    data DATE,
    temperatura FLOAT,
    umiditate FLOAT,
    vant INT,
    precipitatii VARCHAR(255),
    presiune INT,
    codLocatie VARCHAR(255),
    FOREIGN KEY (codLocatie) REFERENCES Locatii(cod) ON DELETE CASCADE
);

INSERT INTO Locatii (cod, denumire, tip, municipiu) VALUES
('L1', 'Locatie 1', 'A', 'Municipiul A'),
('L2', 'Locatie 2', 'B', 'Municipiul B'),
('L3', 'Locatie 3', 'A', 'Municipiul C'),
('L4', 'Locatie 4', 'C', 'Municipiul D'),
('L5', 'Locatie 5', 'B', 'Municipiul E');

INSERT INTO DateMeteo (cod, data, temperatura, umiditate, vant, precipitatii, presiune, codLocatie) VALUES
('D1', '2024-06-01', 25.5, 70.0, 10, 'Ploaie ușoară', 1010, 'L1'),
('D2', '2024-06-02', 27.0, 68.5, 8, 'Cer senin', 1005, 'L2'),
('D3', '2024-06-03', 24.8, 72.3, 12, 'Burniță', 1008, 'L3'),
('D4', '2024-06-04', 26.5, 65.7, 15, 'Cer acoperit', 1002, 'L4'),
('D5', '2024-06-05', 28.2, 63.2, 18, 'Furtună', 995, 'L5');


-- CREATE USER 'catalin'@'localhost' IDENTIFIED BY 'catalin';
-- GRANT ALL PRIVILEGES ON *.* TO 'catalin'@'localhost' WITH GRANT OPTION;